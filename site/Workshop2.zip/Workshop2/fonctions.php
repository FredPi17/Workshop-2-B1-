<?php

  function Random($Questions){
    $nb=rand(0, count($Questions)-1);
    return($nb);
// Désalouer le tableau a la fin de réponse
  }

 ?>